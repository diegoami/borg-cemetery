# D0001-rust-seed1000099: a soldier at turn 51340

Elf Warrior, character level 5, depth 1 (max 2), seed 1000099, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `e153c084d238`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r2-s1000099-i000/run` (not committed).

Core decision trace: the last 6 of 6 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
