# D0001-rust-seed1060078: Grip, Farmer Maggot's Dog at turn 63185

Hobbit Rogue, character level 3, depth 1 (max 2), seed 1060078, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `72341fa526d6`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r3-s1060078-i000/run` (not committed).

Core decision trace: the last 67 of 67 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
