# D0001-rust-seed1020028: an apprentice at turn 64810

Dwarf Druid, character level 4, depth 2 (max 2), seed 1020028, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `4321f4cd2101`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r5-s1020028-i001/run` (not committed).

Core decision trace: the last 11 of 11 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
