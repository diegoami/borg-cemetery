# D0001-rust-seed1010067: a soldier at turn 40791

Hobbit Mage, character level 4, depth 2 (max 2), seed 1010067, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `2c9b5f3fb25d`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r3-s1010067-i000/run` (not committed).

Core decision trace: the last 16 of 16 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
