# D0001-rust-seed1070010: an apprentice at turn 68612

High-Elf Ranger, character level 3, depth 1 (max 1), seed 1070010, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `4a3af65f634f`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r9-s1070010-i000/run` (not committed).

Core decision trace: the last 30 of 30 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
