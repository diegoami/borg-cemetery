# D0001-rust-seed1040054: Fang, Farmer Maggot's Dog at turn 12060

High-Elf Necromancer, character level 1, depth 1 (max 1), seed 1040054, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `29a11bec82c0`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r9-s1040054-i000/run` (not committed).

Core decision trace: the last 24 of 24 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
