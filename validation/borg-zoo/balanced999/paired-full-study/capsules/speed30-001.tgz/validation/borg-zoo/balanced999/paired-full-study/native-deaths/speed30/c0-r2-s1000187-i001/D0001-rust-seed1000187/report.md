# D0001-rust-seed1000187: Bullroarer the Hobbit at turn 80987

Elf Warrior, character level 7, depth 3 (max 3), seed 1000187, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `30f88606e77c`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r2-s1000187-i001/run` (not committed).

Core decision trace: the last 20 of 20 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
