# D0001-rust-seed1050031: poison at turn 52790

Dunadan Paladin, character level 6, depth 3 (max 3), seed 1050031, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `e71ffd5b5ca0`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r8-s1050031-i001/run` (not committed).

Core decision trace: the last 10 of 10 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
