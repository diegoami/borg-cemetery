# D0001-rust-seed1020029: a small kobold at turn 26960

Half-Orc Druid, character level 2, depth 1 (max 1), seed 1020029, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `b594d1fb2bca`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r6-s1020029-i000/run` (not committed).

Core decision trace: the last 6 of 6 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
