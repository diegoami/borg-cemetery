# D0001-rust-seed1060035: a soldier at turn 63271

Gnome Rogue, character level 4, depth 2 (max 2), seed 1060035, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `c0b9d30a81c8`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r4-s1060035-i000/run` (not committed).

Core decision trace: the last 8 of 8 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
