# D0001-rust-seed1000150: a clear worm mass at turn 86277

Half-Orc Warrior, character level 13, depth 2 (max 2), seed 1000150, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `efd0d94f9b47`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r6-s1000150-i000/run` (not committed).

Decision trace: the last 84 of 84 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
