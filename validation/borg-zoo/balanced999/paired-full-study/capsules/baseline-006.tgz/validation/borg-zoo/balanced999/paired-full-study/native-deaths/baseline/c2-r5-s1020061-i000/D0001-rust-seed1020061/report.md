# D0001-rust-seed1020061: a mean-looking mercenary at turn 1099

Dwarf Druid, character level 1, depth 0 (max 0), seed 1020061, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `6e9ea16b255c`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r5-s1020061-i000/run` (not committed).

Decision trace: the last 80 of 80 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
