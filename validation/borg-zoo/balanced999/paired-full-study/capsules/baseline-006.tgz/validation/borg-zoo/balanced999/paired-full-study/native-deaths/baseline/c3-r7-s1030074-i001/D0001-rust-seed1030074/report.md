# D0001-rust-seed1030074: poison at turn 91600

Half-Troll Priest, character level 8, depth 1 (max 1), seed 1030074, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `dcc1c45a68b0`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r7-s1030074-i001/run` (not committed).

Decision trace: the last 30 of 30 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
