# D0001-rust-seed1070049: a soldier at turn 89849

Human Ranger, character level 4, depth 2 (max 2), seed 1070049, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `60672dd1fdfb`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r0-s1070049-i001/run` (not committed).

Decision trace: the last 16 of 16 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
