# D0001-rust-seed1060096: a small kobold at turn 82135

Half-Troll Rogue, character level 7, depth 2 (max 3), seed 1060096, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `62a6e0e488f3`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r7-s1060096-i001/run` (not committed).

Decision trace: the last 36 of 36 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
