# D0001-rust-seed1000149: a soldier at turn 85961

Dwarf Warrior, character level 8, depth 2 (max 3), seed 1000149, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `e5b9cc421bce`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r5-s1000149-i000/run` (not committed).

Decision trace: the last 19 of 19 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
