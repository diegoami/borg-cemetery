# D0001-rust-seed1030046: a cave spider at turn 50780

Gnome Priest, character level 5, depth 2 (max 3), seed 1030046, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `ef5c1f123c63`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r4-s1030046-i004/run` (not committed).

Decision trace: the last 8 of 8 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
