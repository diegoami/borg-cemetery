# D0001-rust-seed1000236: a gallant at turn 90375

Human Warrior, character level 8, depth 4 (max 4), seed 1000236, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `15789976f63b`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r0-s1000236-i002/run` (not committed).

Decision trace: the last 41 of 41 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
