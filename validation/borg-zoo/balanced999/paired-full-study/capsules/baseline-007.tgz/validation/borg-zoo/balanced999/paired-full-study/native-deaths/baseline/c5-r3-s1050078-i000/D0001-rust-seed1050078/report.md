# D0001-rust-seed1050078: a soldier at turn 82281

Hobbit Paladin, character level 5, depth 2 (max 2), seed 1050078, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `bd4f6cc741b1`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r3-s1050078-i000/run` (not committed).

Decision trace: the last 8 of 8 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
