# D0001-rust-seed1050113: a floating eye at turn 34919

Kobold Paladin, character level 4, depth 1 (max 1), seed 1050113, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `2b31372a4ccd`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r10-s1050113-i001/run` (not committed).

Core decision trace: the last 4 of 4 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
