# D0001-rust-seed1060074: a giant white louse at turn 82392

Half-Troll Rogue, character level 9, depth 3 (max 3), seed 1060074, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `c80db813cc4c`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r7-s1060074-i000/run` (not committed).

Core decision trace: the last 110 of 110 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
