# D0001-rust-seed1040040: poison at turn 25710

Half-Orc Necromancer, character level 2, depth 1 (max 1), seed 1040040, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `3857d7b52429`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r6-s1040040-i000/run` (not committed).

Core decision trace: the last 11 of 11 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
