# D0001-rust-seed1050078: a soldier at turn 82292

Hobbit Paladin, character level 5, depth 2 (max 2), seed 1050078, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `cdb8e4f52444`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r3-s1050078-i000/run` (not committed).

Core decision trace: the last 12 of 12 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
