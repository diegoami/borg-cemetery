# D0001-rust-seed1080065: a red naga at turn 89745

High-Elf Blackguard, character level 7, depth 3 (max 3), seed 1080065, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `c71bc8325b71`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c8-r9-s1080065-i001/run` (not committed).

Core decision trace: the last 29 of 29 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
