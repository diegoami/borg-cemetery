# D0001-rust-seed1000261: a soldier at turn 82523

Half-Troll Warrior, character level 7, depth 2 (max 3), seed 1000261, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `00e5370c2b10`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r7-s1000261-i000/run` (not committed).

Core decision trace: the last 14 of 14 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
