# D0001-rust-seed1000166: a giant white louse at turn 65545

Hobbit Warrior, character level 8, depth 3 (max 3), seed 1000166, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `31b9e08c573f`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r3-s1000166-i000/run` (not committed).

Core decision trace: the last 69 of 69 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
