# D0001-rust-seed1000249: a soldier at turn 29741

Half-Orc Warrior, character level 5, depth 2 (max 2), seed 1000249, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `ce8dc8d08c0c`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r6-s1000249-i000/run` (not committed).

Core decision trace: the last 5 of 5 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
