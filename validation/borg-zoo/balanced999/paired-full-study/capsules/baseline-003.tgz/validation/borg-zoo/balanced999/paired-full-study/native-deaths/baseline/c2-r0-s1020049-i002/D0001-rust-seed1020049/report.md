# D0001-rust-seed1020049: a giant yellow centipede at turn 12084

Human Druid, character level 1, depth 1 (max 1), seed 1020049, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `bac3d2e67c27`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r0-s1020049-i002/run` (not committed).

Decision trace: the last 4 of 4 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
