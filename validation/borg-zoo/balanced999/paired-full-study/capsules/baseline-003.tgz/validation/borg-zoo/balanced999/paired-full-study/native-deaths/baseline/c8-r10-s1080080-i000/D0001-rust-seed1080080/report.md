# D0001-rust-seed1080080: a soldier at turn 7571

Kobold Blackguard, character level 2, depth 1 (max 1), seed 1080080, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `66fb831caa1a`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c8-r10-s1080080-i000/run` (not committed).

Decision trace: the last 7 of 7 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
