# D0001-rust-seed1070063: an apprentice at turn 60677

Half-Troll Ranger, character level 5, depth 2 (max 2), seed 1070063, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `7b7c35f61112`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r7-s1070063-i000/run` (not committed).

Decision trace: the last 25 of 25 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
