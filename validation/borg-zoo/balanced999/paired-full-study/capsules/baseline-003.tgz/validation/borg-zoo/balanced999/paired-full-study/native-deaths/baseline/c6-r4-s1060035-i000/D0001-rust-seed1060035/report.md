# D0001-rust-seed1060035: a soldier at turn 63277

Gnome Rogue, character level 4, depth 2 (max 2), seed 1060035, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `1c1b9ada3d4e`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r4-s1060035-i000/run` (not committed).

Decision trace: the last 9 of 9 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
