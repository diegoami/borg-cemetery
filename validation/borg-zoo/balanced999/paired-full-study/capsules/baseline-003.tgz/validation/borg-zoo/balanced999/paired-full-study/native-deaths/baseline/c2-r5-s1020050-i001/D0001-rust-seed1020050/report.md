# D0001-rust-seed1020050: a soldier at turn 45619

Dwarf Druid, character level 4, depth 2 (max 3), seed 1020050, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `f5b60ab1c0bd`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r5-s1020050-i001/run` (not committed).

Decision trace: the last 12 of 12 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
