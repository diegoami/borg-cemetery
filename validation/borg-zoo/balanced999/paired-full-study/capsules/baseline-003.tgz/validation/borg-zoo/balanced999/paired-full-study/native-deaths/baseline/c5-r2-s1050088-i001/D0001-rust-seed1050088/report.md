# D0001-rust-seed1050088: a giant white mouse at turn 51327

Elf Paladin, character level 4, depth 1 (max 1), seed 1050088, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `27f2fc0e8da1`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r2-s1050088-i001/run` (not committed).

Decision trace: the last 3 of 3 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
