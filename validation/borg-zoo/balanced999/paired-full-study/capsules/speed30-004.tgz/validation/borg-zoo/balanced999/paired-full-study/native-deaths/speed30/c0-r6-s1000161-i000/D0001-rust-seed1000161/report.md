# D0001-rust-seed1000161: a giant white louse at turn 80309

Half-Orc Warrior, character level 9, depth 3 (max 3), seed 1000161, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `8330d36a9b5c`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r6-s1000161-i000/run` (not committed).

Core decision trace: the last 23 of 23 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
