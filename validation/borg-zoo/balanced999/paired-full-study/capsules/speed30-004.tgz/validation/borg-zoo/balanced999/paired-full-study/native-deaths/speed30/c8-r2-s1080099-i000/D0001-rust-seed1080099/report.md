# D0001-rust-seed1080099: poison at turn 22940

Elf Blackguard, character level 4, depth 1 (max 1), seed 1080099, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `e21c09b6cef4`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c8-r2-s1080099-i000/run` (not committed).

Core decision trace: the last 120 of 120 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
