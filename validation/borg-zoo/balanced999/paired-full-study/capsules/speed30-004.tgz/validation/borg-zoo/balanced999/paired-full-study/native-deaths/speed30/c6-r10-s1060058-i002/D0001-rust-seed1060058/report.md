# D0001-rust-seed1060058: a soldier at turn 38758

Kobold Rogue, character level 6, depth 2 (max 2), seed 1060058, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `36e56fc50174`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r10-s1060058-i002/run` (not committed).

Core decision trace: the last 17 of 17 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
