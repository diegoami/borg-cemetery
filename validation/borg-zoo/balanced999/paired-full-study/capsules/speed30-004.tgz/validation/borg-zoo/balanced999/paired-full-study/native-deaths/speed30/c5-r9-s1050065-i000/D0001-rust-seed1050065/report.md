# D0001-rust-seed1050065: a soldier at turn 55218

High-Elf Paladin, character level 4, depth 2 (max 2), seed 1050065, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `efdcf6d86dc6`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r9-s1050065-i000/run` (not committed).

Core decision trace: the last 32 of 32 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
