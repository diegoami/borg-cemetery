# D0001-rust-seed1080084: a spotted mushroom patch at turn 91932

Half-Orc Blackguard, character level 8, depth 4 (max 5), seed 1080084, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `84078ddf88ab`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c8-r6-s1080084-i002/run` (not committed).

Core decision trace: the last 78 of 78 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
