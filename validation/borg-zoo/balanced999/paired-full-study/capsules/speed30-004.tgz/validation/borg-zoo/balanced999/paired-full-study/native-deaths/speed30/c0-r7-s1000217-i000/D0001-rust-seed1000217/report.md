# D0001-rust-seed1000217: a giant white louse at turn 63643

Half-Troll Warrior, character level 10, depth 3 (max 3), seed 1000217, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `975a1c4992be`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r7-s1000217-i000/run` (not committed).

Core decision trace: the last 80 of 80 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
