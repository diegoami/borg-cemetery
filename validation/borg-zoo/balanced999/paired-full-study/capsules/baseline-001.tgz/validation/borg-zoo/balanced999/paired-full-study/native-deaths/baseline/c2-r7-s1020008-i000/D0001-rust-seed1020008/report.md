# D0001-rust-seed1020008: an acolyte at turn 80981

Half-Troll Druid, character level 5, depth 3 (max 3), seed 1020008, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `c3f1757ac2a1`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r7-s1020008-i000/run` (not committed).

Decision trace: the last 38 of 38 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
