# D0001-rust-seed1040012: a grey mushroom patch at turn 2437

Hobbit Necromancer, character level 1, depth 1 (max 1), seed 1040012, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `8a4231f573a3`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r3-s1040012-i000/run` (not committed).

Decision trace: the last 30 of 30 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
