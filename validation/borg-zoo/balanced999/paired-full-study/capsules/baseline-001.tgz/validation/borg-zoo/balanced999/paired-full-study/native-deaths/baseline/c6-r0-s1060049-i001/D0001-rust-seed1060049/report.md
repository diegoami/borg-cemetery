# D0001-rust-seed1060049: a kobold at turn 91738

Human Rogue, character level 7, depth 2 (max 3), seed 1060049, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `3e008a53da4e`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r0-s1060049-i001/run` (not committed).

Decision trace: the last 22 of 22 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
