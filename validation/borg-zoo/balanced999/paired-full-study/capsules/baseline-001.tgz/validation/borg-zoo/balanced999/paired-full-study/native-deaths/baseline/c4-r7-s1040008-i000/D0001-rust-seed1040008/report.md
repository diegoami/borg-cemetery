# D0001-rust-seed1040008: a green worm mass at turn 81236

Half-Troll Necromancer, character level 8, depth 3 (max 3), seed 1040008, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `d68c183a434e`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r7-s1040008-i000/run` (not committed).

Decision trace: the last 13 of 13 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
