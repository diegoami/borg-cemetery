# D0001-rust-seed1020030: Grip, Farmer Maggot's Dog at turn 58287

Half-Troll Druid, character level 4, depth 2 (max 2), seed 1020030, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `8ca8d9068d55`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r7-s1020030-i000/run` (not committed).

Decision trace: the last 18 of 18 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
