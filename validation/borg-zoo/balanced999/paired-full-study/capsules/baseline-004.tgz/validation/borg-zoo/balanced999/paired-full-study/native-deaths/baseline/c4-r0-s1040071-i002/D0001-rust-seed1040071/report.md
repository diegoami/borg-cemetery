# D0001-rust-seed1040071: a cave spider at turn 6661

Human Necromancer, character level 2, depth 1 (max 1), seed 1040071, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `9f3873f29b60`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r0-s1040071-i002/run` (not committed).

Decision trace: the last 6 of 6 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
