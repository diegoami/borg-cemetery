# D0001-rust-seed1070070: an acolyte at turn 7017

Half-Elf Ranger, character level 3, depth 1 (max 1), seed 1070070, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `c60b6b11ed1b`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r1-s1070070-i000/run` (not committed).

Decision trace: the last 156 of 156 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
