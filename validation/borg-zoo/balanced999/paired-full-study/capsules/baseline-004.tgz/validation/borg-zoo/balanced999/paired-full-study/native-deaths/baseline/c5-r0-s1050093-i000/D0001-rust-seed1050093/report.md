# D0001-rust-seed1050093: a kobold shaman at turn 51280

Human Paladin, character level 6, depth 3 (max 3), seed 1050093, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `104c2c0619fc`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r0-s1050093-i000/run` (not committed).

Decision trace: the last 20 of 20 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
