# D0001-rust-seed1070070: a kobold shaman at turn 78438

Half-Elf Ranger, character level 6, depth 3 (max 4), seed 1070070, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `8b6b1c1fedaa`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r1-s1070070-i003/run` (not committed).

Decision trace: the last 10 of 10 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
