# D0001-rust-seed1030092: a fatal wound at turn 27620

Half-Elf Priest, character level 3, depth 1 (max 1), seed 1030092, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `3b6696141946`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r1-s1030092-i000/run` (not committed).

Decision trace: the last 50 of 50 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
