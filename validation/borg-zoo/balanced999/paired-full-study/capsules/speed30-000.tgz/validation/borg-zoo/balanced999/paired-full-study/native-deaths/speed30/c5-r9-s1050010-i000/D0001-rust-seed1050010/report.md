# D0001-rust-seed1050010: a giant white louse at turn 84320

High-Elf Paladin, character level 8, depth 3 (max 4), seed 1050010, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `13f09f5825dc`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r9-s1050010-i000/run` (not committed).

Core decision trace: the last 200 of 242 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
