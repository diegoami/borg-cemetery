# D0001-rust-seed1020003: a grey mold at turn 19580

Kobold Druid, character level 2, depth 1 (max 2), seed 1020003, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `53d301148f86`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r10-s1020003-i000/run` (not committed).

Core decision trace: the last 18 of 18 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
