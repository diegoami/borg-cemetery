# D0001-rust-seed1000103: a kobold archer at turn 88915

Half-Elf Warrior, character level 8, depth 4 (max 4), seed 1000103, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `4abb5142c653`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r1-s1000103-i000/run` (not committed).

Core decision trace: the last 21 of 21 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
