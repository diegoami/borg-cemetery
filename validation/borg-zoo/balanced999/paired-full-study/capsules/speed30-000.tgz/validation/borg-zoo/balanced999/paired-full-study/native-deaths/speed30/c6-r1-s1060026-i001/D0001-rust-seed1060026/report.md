# D0001-rust-seed1060026: an acolyte at turn 50575

Half-Elf Rogue, character level 5, depth 2 (max 2), seed 1060026, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `151d6943d0fc`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r1-s1060026-i001/run` (not committed).

Core decision trace: the last 11 of 11 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
