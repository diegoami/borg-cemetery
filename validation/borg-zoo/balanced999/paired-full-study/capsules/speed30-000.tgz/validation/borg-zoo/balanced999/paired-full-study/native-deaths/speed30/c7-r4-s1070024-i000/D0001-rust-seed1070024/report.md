# D0001-rust-seed1070024: a grey mold at turn 45409

Gnome Ranger, character level 3, depth 1 (max 2), seed 1070024, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `513dd82f4dc6`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r4-s1070024-i000/run` (not committed).

Core decision trace: the last 146 of 146 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
