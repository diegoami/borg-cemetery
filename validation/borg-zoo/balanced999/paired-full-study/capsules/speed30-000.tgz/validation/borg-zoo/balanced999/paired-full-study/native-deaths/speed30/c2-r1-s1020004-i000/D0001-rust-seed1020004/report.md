# D0001-rust-seed1020004: a giant yellow centipede at turn 1311

Half-Elf Druid, character level 1, depth 1 (max 1), seed 1020004, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `62c510a1552b`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r1-s1020004-i000/run` (not committed).

Core decision trace: the last 11 of 11 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
