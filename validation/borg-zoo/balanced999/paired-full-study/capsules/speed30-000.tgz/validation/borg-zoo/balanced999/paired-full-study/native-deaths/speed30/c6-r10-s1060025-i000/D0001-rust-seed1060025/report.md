# D0001-rust-seed1060025: a cutpurse at turn 77614

Kobold Rogue, character level 5, depth 2 (max 2), seed 1060025, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `a4cd5cfee350`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r10-s1060025-i000/run` (not committed).

Core decision trace: the last 12 of 12 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
