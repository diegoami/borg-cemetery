# D0001-rust-seed1040076: a cave spider at turn 70984

High-Elf Necromancer, character level 5, depth 2 (max 2), seed 1040076, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `4bd2d6806936`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r9-s1040076-i002/run` (not committed).

Core decision trace: the last 10 of 10 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
