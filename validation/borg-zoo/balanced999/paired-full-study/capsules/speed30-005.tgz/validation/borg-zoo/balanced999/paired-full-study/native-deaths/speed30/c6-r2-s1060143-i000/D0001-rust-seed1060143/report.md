# D0001-rust-seed1060143: Fang, Farmer Maggot's Dog at turn 3709

Elf Rogue, character level 1, depth 1 (max 1), seed 1060143, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `3b16de368e71`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r2-s1060143-i000/run` (not committed).

Core decision trace: the last 20 of 20 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
