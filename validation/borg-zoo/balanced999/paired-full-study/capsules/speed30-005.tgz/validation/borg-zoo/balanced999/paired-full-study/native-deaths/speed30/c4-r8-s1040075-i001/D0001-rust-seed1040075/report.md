# D0001-rust-seed1040075: a soldier at turn 54101

Dunadan Necromancer, character level 3, depth 1 (max 1), seed 1040075, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `0030ef73c406`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r8-s1040075-i001/run` (not committed).

Core decision trace: the last 6 of 6 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
