# D0001-rust-seed1030093: a green worm mass at turn 25663

Human Priest, character level 6, depth 2 (max 2), seed 1030093, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `919e7a99f7d1`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r0-s1030093-i001/run` (not committed).

Core decision trace: the last 76 of 76 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
