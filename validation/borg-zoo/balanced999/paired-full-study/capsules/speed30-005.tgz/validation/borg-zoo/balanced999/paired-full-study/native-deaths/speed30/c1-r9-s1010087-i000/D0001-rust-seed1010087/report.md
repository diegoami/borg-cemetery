# D0001-rust-seed1010087: Fang, Farmer Maggot's Dog at turn 21724

High-Elf Mage, character level 2, depth 1 (max 1), seed 1010087, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `5075e78eb368`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r9-s1010087-i000/run` (not committed).

Core decision trace: the last 13 of 13 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
