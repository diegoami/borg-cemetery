# D0001-rust-seed1050094: a kobold at turn 55647

Dwarf Paladin, character level 6, depth 3 (max 3), seed 1050094, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `8137a093d62e`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r5-s1050094-i000/run` (not committed).

Core decision trace: the last 6 of 6 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
