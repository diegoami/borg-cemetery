# D0001-rust-seed1000296: a giant white louse at turn 86849

High-Elf Warrior, character level 8, depth 3 (max 3), seed 1000296, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `790d3b0d1763`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r9-s1000296-i001/run` (not committed).

Core decision trace: the last 50 of 50 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
