# D0001-rust-seed1030060: a soldier at turn 50576

Human Priest, character level 5, depth 2 (max 2), seed 1030060, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `abf181d25b2b`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r0-s1030060-i001/run` (not committed).

Core decision trace: the last 7 of 7 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
