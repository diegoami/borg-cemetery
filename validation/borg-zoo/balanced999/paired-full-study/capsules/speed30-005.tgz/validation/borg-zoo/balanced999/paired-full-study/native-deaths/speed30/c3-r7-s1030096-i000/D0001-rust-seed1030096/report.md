# D0001-rust-seed1030096: a green worm mass at turn 61491

Half-Troll Priest, character level 7, depth 3 (max 3), seed 1030096, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `b2567d2efc1e`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r7-s1030096-i000/run` (not committed).

Core decision trace: the last 69 of 69 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
