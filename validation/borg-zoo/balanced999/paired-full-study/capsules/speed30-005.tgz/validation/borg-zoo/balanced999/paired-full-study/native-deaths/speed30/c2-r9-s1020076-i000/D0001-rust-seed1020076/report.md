# D0001-rust-seed1020076: a small kobold at turn 29010

High-Elf Druid, character level 2, depth 1 (max 1), seed 1020076, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `5e51687a103d`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r9-s1020076-i000/run` (not committed).

Core decision trace: the last 12 of 12 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
