# D0001-rust-seed1040073: a cave spider at turn 11551

Half-Orc Necromancer, character level 2, depth 1 (max 1), seed 1040073, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `78f8ff908ed4`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r6-s1040073-i001/run` (not committed).

Core decision trace: the last 5 of 5 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
