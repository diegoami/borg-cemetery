# D0001-rust-seed1000296: a giant white louse at turn 86753

High-Elf Warrior, character level 8, depth 3 (max 3), seed 1000296, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `43789873c312`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r9-s1000296-i001/run` (not committed).

Decision trace: the last 12 of 12 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
