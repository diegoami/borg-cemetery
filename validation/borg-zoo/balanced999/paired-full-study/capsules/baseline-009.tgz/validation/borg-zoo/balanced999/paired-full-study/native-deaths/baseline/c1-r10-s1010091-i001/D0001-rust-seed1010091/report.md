# D0001-rust-seed1010091: a giant yellow centipede at turn 17877

Kobold Mage, character level 2, depth 1 (max 1), seed 1010091, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `fd0bd3dc9b16`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r10-s1010091-i001/run` (not committed).

Decision trace: the last 8 of 8 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
