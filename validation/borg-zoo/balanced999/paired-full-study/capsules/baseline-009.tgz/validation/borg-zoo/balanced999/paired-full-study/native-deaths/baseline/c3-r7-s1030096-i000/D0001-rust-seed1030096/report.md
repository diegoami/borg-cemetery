# D0001-rust-seed1030096: a green worm mass at turn 60989

Half-Troll Priest, character level 7, depth 3 (max 3), seed 1030096, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `a8ce3e13838f`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r7-s1030096-i000/run` (not committed).

Decision trace: the last 19 of 19 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
