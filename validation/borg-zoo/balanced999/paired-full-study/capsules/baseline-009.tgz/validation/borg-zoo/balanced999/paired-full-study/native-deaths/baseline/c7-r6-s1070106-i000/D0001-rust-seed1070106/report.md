# D0001-rust-seed1070106: a kobold archer at turn 93627

Half-Orc Ranger, character level 5, depth 2 (max 2), seed 1070106, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `67a5d24c5159`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r6-s1070106-i000/run` (not committed).

Decision trace: the last 27 of 27 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
