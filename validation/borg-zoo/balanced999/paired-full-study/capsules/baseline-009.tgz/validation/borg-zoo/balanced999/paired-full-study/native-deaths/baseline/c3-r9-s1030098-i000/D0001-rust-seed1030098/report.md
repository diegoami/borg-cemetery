# D0001-rust-seed1030098: a giant white louse at turn 79516

High-Elf Priest, character level 5, depth 2 (max 2), seed 1030098, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `958470f418e3`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r9-s1030098-i000/run` (not committed).

Decision trace: the last 42 of 42 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
