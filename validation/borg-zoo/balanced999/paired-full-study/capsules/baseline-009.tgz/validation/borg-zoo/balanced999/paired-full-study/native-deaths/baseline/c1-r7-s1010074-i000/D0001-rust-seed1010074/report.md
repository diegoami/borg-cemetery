# D0001-rust-seed1010074: a soldier at turn 92042

Half-Troll Mage, character level 6, depth 3 (max 3), seed 1010074, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `efb40c59193a`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r7-s1010074-i000/run` (not committed).

Decision trace: the last 55 of 55 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
