# D0001-rust-seed1050136: a green naga at turn 68907

Half-Elf Paladin, character level 6, depth 3 (max 3), seed 1050136, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `9e8df9a486d5`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r1-s1050136-i000/run` (not committed).

Decision trace: the last 14 of 14 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
