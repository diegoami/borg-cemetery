# D0001-rust-seed1030083: a giant white mouse at turn 77528

Dwarf Priest, character level 8, depth 2 (max 2), seed 1030083, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `4839b700d64d`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r5-s1030083-i001/run` (not committed).

Decision trace: the last 13 of 13 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
