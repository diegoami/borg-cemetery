# D0001-rust-seed1000314: a black naga at turn 59245

Dwarf Warrior, character level 6, depth 3 (max 3), seed 1000314, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `2e925b3334f6`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r5-s1000314-i000/run` (not committed).

Decision trace: the last 16 of 16 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
