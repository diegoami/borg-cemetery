# D0001-rust-seed1050132: an acolyte at turn 24845

Elf Paladin, character level 4, depth 2 (max 3), seed 1050132, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `886ba1a64d7f`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r2-s1050132-i001/run` (not committed).

Decision trace: the last 14 of 14 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
