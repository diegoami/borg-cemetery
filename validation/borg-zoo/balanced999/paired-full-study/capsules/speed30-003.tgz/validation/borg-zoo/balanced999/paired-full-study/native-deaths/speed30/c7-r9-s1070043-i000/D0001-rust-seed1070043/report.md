# D0001-rust-seed1070043: an acolyte at turn 8704

High-Elf Ranger, character level 2, depth 1 (max 1), seed 1070043, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `0365291db98a`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r9-s1070043-i000/run` (not committed).

Core decision trace: the last 1 of 1 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
