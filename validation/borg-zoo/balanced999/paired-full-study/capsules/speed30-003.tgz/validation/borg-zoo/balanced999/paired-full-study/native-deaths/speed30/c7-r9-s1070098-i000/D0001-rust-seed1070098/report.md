# D0001-rust-seed1070098: a large kobold at turn 80331

High-Elf Ranger, character level 6, depth 3 (max 3), seed 1070098, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `9073aa1cb409`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r9-s1070098-i000/run` (not committed).

Core decision trace: the last 17 of 17 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
