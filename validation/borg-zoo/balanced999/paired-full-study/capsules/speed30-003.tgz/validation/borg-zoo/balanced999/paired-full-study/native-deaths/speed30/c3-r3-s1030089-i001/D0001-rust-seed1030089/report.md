# D0001-rust-seed1030089: a gallant at turn 47320

Hobbit Priest, character level 5, depth 1 (max 1), seed 1030089, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `6de35b51d734`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r3-s1030089-i001/run` (not committed).

Core decision trace: the last 48 of 48 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
