# D0001-rust-seed1080123: Grip, Farmer Maggot's Dog at turn 8019

Gnome Blackguard, character level 2, depth 1 (max 1), seed 1080123, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `2d9d3d9ab9f4`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c8-r4-s1080123-i000/run` (not committed).

Core decision trace: the last 2 of 2 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
