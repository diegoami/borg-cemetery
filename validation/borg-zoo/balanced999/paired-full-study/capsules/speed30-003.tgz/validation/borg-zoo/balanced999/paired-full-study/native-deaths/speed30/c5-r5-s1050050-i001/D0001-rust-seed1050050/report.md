# D0001-rust-seed1050050: a soldier at turn 41468

Dwarf Paladin, character level 6, depth 2 (max 2), seed 1050050, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `66bc29803615`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r5-s1050050-i001/run` (not committed).

Core decision trace: the last 9 of 9 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
