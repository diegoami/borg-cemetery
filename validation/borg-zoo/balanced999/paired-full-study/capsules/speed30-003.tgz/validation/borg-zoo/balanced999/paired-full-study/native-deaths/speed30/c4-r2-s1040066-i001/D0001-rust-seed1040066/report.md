# D0001-rust-seed1040066: a grey mushroom patch at turn 87218

Elf Necromancer, character level 6, depth 2 (max 2), seed 1040066, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `89239f479ca9`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r2-s1040066-i001/run` (not committed).

Core decision trace: the last 32 of 32 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
