# D0001-rust-seed1060092: a giant white louse at turn 72241

Half-Elf Rogue, character level 7, depth 3 (max 3), seed 1060092, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `a7049ba1840b`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r1-s1060092-i000/run` (not committed).

Core decision trace: the last 117 of 117 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
