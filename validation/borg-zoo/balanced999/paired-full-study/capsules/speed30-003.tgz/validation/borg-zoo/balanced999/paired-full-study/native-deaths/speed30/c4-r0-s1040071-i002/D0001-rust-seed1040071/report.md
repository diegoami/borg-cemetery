# D0001-rust-seed1040071: a cave spider at turn 6646

Human Necromancer, character level 2, depth 1 (max 1), seed 1040071, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `64a534ac8ad7`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r0-s1040071-i002/run` (not committed).

Core decision trace: the last 5 of 5 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
