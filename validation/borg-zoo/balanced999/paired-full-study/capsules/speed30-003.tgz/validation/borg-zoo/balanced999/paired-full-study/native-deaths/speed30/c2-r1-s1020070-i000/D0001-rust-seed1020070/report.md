# D0001-rust-seed1020070: a wild cat at turn 5478

Half-Elf Druid, character level 1, depth 1 (max 1), seed 1020070, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `d9997d931800`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r1-s1020070-i000/run` (not committed).

Core decision trace: the last 18 of 18 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
