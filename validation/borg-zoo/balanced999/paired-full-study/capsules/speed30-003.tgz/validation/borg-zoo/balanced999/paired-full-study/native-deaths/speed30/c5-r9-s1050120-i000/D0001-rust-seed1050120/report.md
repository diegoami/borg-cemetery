# D0001-rust-seed1050120: a scout at turn 58418

High-Elf Paladin, character level 5, depth 2 (max 2), seed 1050120, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `48cbf002c0b5`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r9-s1050120-i000/run` (not committed).

Core decision trace: the last 12 of 12 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
