# D0001-rust-seed1070044: a soldier at turn 6359

Elf Ranger, character level 1, depth 1 (max 1), seed 1070044, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `4c803f86ecef`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r2-s1070044-i000/run` (not committed).

Core decision trace: the last 6 of 6 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
