# D0001-rust-seed1010078: a cutpurse at turn 38475

Hobbit Mage, character level 2, depth 1 (max 1), seed 1010078, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `f3bc7a50c0c5`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r3-s1010078-i000/run` (not committed).

Core decision trace: the last 12 of 12 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
