# D0001-rust-seed1080057: a soldier at turn 64587

Gnome Blackguard, character level 6, depth 3 (max 3), seed 1080057, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `fb36832b70e3`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c8-r4-s1080057-i000/run` (not committed).

Core decision trace: the last 20 of 20 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
