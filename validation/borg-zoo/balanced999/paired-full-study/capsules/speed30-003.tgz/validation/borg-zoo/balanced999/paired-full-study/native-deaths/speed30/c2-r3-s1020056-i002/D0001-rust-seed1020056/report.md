# D0001-rust-seed1020056: a giant yellow centipede at turn 29927

Hobbit Druid, character level 1, depth 1 (max 1), seed 1020056, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `5c24a57c6ba9`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r3-s1020056-i002/run` (not committed).

Core decision trace: the last 3 of 3 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
