# D0001-rust-seed1040026: a cave spider at turn 8890

Half-Elf Necromancer, character level 2, depth 1 (max 1), seed 1040026, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `6b159c421102`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r1-s1040026-i000/run` (not committed).

Core decision trace: the last 9 of 9 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
