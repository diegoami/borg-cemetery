# D0001-rust-seed1070094: a giant white mouse at turn 28743

Dwarf Ranger, character level 4, depth 1 (max 1), seed 1070094, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `b82ee6524568`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r5-s1070094-i000/run` (not committed).

Core decision trace: the last 118 of 118 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
