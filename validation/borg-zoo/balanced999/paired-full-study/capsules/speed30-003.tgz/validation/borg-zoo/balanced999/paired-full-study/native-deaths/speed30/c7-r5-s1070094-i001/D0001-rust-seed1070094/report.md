# D0001-rust-seed1070094: Fang, Farmer Maggot's Dog at turn 39469

Dwarf Ranger, character level 5, depth 2 (max 2), seed 1070094, implementation `rust`, flags `menu,keep-load-rng`.

Build `193d9076747cd5c52e1fe1f6ea314570d8f3873a` (dirty: no), binary `cdfee89a0d85`. Keys `771a76ad5385`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r5-s1070094-i001/run` (not committed).

Core decision trace: the last 38 of 38 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
