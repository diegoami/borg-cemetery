# D0001-rust-seed1030045: a wild cat at turn 49361

Hobbit Priest, character level 4, depth 2 (max 2), seed 1030045, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `1b396c2401c0`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r3-s1030045-i002/run` (not committed).

Decision trace: the last 16 of 16 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
