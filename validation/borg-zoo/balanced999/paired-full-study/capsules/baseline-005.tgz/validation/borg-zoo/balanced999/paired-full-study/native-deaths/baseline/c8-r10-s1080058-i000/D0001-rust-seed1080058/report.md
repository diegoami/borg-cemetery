# D0001-rust-seed1080058: a cutpurse at turn 3171

Kobold Blackguard, character level 4, depth 2 (max 2), seed 1080058, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `6b990d73f80c`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c8-r10-s1080058-i000/run` (not committed).

Decision trace: the last 130 of 130 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
