# D0001-rust-seed1060062: a cave spider at turn 30242

Half-Orc Rogue, character level 4, depth 2 (max 2), seed 1060062, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `3e68a1f7abb4`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r6-s1060062-i000/run` (not committed).

Decision trace: the last 4 of 4 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
