# D0001-rust-seed1070044: a soldier at turn 6377

Elf Ranger, character level 1, depth 1 (max 1), seed 1070044, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `046b75e24153`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r2-s1070044-i000/run` (not committed).

Decision trace: the last 8 of 8 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
