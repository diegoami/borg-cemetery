# D0001-rust-seed1010034: an apprentice at turn 59794

Hobbit Mage, character level 5, depth 2 (max 2), seed 1010034, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `8fd6d20664b9`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r3-s1010034-i001/run` (not committed).

Decision trace: the last 1 of 1 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
