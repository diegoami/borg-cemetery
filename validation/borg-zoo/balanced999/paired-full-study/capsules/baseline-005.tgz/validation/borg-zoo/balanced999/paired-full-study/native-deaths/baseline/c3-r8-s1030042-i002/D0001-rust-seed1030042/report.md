# D0001-rust-seed1030042: a floating eye at turn 69276

Dunadan Priest, character level 3, depth 1 (max 1), seed 1030042, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `d4c5f17e0469`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c3-r8-s1030042-i002/run` (not committed).

Decision trace: the last 4 of 4 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
