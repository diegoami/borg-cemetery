# D0001-rust-seed1050010: a giant white louse at turn 82918

High-Elf Paladin, character level 7, depth 3 (max 4), seed 1050010, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `76f0af49f7ed`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r9-s1050010-i000/run` (not committed).

Decision trace: the last 30 of 30 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
