# D0001-rust-seed1080008: a giant white louse at turn 83582

Half-Troll Blackguard, character level 10, depth 3 (max 3), seed 1080008, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `d3e8562c3ae7`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c8-r7-s1080008-i000/run` (not committed).

Decision trace: the last 118 of 118 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
