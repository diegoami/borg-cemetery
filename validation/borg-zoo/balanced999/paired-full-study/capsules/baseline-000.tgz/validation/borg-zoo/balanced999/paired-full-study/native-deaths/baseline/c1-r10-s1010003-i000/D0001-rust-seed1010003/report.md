# D0001-rust-seed1010003: a battle-scarred veteran at turn 1347

Kobold Mage, character level 1, depth 0 (max 0), seed 1010003, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `cf74e2f3adde`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r10-s1010003-i000/run` (not committed).

Decision trace: the last 128 of 128 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
