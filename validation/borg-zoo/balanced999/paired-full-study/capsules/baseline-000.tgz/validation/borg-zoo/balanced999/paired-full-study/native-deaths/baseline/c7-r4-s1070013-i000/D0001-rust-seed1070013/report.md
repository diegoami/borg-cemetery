# D0001-rust-seed1070013: a white worm mass at turn 22666

Gnome Ranger, character level 3, depth 1 (max 1), seed 1070013, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `986fd0decff3`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c7-r4-s1070013-i000/run` (not committed).

Decision trace: the last 147 of 147 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
