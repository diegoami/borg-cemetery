# D0001-rust-seed1040053: a grey mold at turn 4166

Dunadan Necromancer, character level 1, depth 1 (max 1), seed 1040053, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `4cdf93bce7e9`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c4-r8-s1040053-i000/run` (not committed).

Decision trace: the last 7 of 7 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
