# D0001-rust-seed1010051: a green glutton ghost at turn 77837

Half-Orc Mage, character level 6, depth 3 (max 3), seed 1010051, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `247bf45af3c8`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r6-s1010051-i000/run` (not committed).

Decision trace: the last 53 of 53 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
