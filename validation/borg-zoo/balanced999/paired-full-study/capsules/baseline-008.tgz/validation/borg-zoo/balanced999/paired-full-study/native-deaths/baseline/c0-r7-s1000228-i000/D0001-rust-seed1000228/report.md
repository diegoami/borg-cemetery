# D0001-rust-seed1000228: a small kobold at turn 83278

Half-Troll Warrior, character level 8, depth 2 (max 4), seed 1000228, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `4eea42c37d8c`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r7-s1000228-i000/run` (not committed).

Decision trace: the last 54 of 54 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
