# D0001-rust-seed1050040: a giant white mouse at turn 77154

Half-Orc Paladin, character level 7, depth 1 (max 1), seed 1050040, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `c7a1a6167b2f`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r6-s1050040-i000/run` (not committed).

Decision trace: the last 10 of 10 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
