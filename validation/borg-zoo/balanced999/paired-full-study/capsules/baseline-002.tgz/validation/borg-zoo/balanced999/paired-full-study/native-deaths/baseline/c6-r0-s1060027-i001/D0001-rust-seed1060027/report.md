# D0001-rust-seed1060027: a soldier at turn 50357

Human Rogue, character level 5, depth 2 (max 2), seed 1060027, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `d18cbdbc4949`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c6-r0-s1060027-i001/run` (not committed).

Decision trace: the last 6 of 6 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
