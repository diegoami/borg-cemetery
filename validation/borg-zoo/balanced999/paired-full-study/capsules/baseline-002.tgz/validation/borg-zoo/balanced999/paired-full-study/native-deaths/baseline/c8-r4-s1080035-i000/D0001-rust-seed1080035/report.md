# D0001-rust-seed1080035: a blacklock mage at turn 46517

Gnome Blackguard, character level 5, depth 3 (max 4), seed 1080035, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `92e654f832f3`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c8-r4-s1080035-i000/run` (not committed).

Decision trace: the last 12 of 12 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
