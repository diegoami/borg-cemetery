# D0001-rust-seed1050023: a cave spider at turn 19549

Hobbit Paladin, character level 2, depth 1 (max 1), seed 1050023, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `8d6ac797dec6`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c5-r3-s1050023-i001/run` (not committed).

Decision trace: the last 16 of 16 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
