# D0001-rust-seed1020025: a clear icky thing at turn 12178

Kobold Druid, character level 1, depth 1 (max 1), seed 1020025, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `4c7326483356`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c2-r10-s1020025-i001/run` (not committed).

Decision trace: the last 18 of 18 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
