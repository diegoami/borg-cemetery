# D0001-rust-seed1010029: a gallant at turn 1719

Half-Orc Mage, character level 2, depth 1 (max 1), seed 1010029, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `869aeabd90e4`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r6-s1010029-i000/run` (not committed).

Decision trace: the last 61 of 61 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
