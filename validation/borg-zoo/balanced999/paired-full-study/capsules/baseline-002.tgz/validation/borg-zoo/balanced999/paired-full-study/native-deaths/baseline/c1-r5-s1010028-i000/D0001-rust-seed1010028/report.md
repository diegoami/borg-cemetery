# D0001-rust-seed1010028: a crow at turn 52575

Dwarf Mage, character level 4, depth 2 (max 3), seed 1010028, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `dd0f7904e027`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c1-r5-s1010028-i000/run` (not committed).

Decision trace: the last 46 of 46 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
