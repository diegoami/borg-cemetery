# D0001-rust-seed1000103: a kobold archer at turn 89059

Half-Elf Warrior, character level 9, depth 4 (max 4), seed 1000103, implementation `rust`, flags `menu,exact,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `67c656e0846d`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempt/native/c0-r1-s1000103-i000/run` (not committed).

Decision trace: the last 38 of 38 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
