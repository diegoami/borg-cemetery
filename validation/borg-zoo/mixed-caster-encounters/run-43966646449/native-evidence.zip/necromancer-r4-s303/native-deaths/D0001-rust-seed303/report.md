# D0001-rust-seed303: a soldier at turn 11710

Gnome Necromancer, character level 2, depth 1 (max 1), seed 303, implementation `rust`, flags `menu,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `8a65a22cd05c`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempts/native/necromancer-r4-s303/run` (not committed).

Decision trace: the last 11 of 11 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
