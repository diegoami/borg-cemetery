# D0001-rust-seed301: Fang, Farmer Maggot's Dog at turn 13674

Dunadan Druid, character level 2, depth 1 (max 1), seed 301, implementation `rust`, flags `menu,keep-load-rng,save=input.save`.

Build `6d1bca10bc67d02150a1a717f111891976e98069` (dirty: no), binary `4105059208c2`. Keys `b627186b79ed`; raw logs stay in `/home/runner/work/borg-zoo/borg-zoo/attempts/native/druid-r8-s301/run` (not committed).

Decision trace: the last 8 of 8 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
