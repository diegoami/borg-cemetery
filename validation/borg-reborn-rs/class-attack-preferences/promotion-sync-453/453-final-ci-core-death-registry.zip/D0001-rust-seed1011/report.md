# D0001-rust-seed1011: a cave spider at turn 18903

Elf Mage, character level 2, depth 1 (max 1), seed 1011, implementation `rust`, flags `menu`.

Build `de96902eb04626bee1a425170af5f34aa40fb0b6` (dirty: no), binary `9472bf6b7396`. Keys `6c02605eeaac`; raw logs stay in `/home/runner/work/borg-reborn-rs/borg-reborn-rs/harness/out/core-trace-death` (not committed).

Core decision trace: the last 200 of 1155 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
