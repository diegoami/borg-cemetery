# D0002-rust-seed1020: a giant white mouse at turn 8922

Elf Druid, character level 2, depth 1 (max 1), seed 1020, implementation `rust`, flags `menu`.

Build `de96902eb04626bee1a425170af5f34aa40fb0b6` (dirty: no), binary `9472bf6b7396`. Keys `c542b7d80373`; raw logs stay in `/home/runner/work/borg-reborn-rs/borg-reborn-rs/harness/out/rerun-source` (not committed).

Decision trace: the last 200 of 751 thinks in `trace-tail.jsonl`; parameters in `params.json` (profile `372785a3dfab`).

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
