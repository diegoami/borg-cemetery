# D0001-rust-seed1011: a cave spider at turn 18903

Elf Mage, character level 2, depth 1 (max 1), seed 1011, implementation `rust`, flags `menu`.

Build `a84f5b118fc44f20e0cc8387dd9f13908cbdc5e3` (dirty: no), binary `fb0d9d322fad`. Keys `6c02605eeaac`; raw logs stay in `/home/runner/work/borg-reborn-rs/borg-reborn-rs/harness/out/core-trace-death` (not committed).

Core decision trace: the last 200 of 1155 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
