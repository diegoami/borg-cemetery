# D0001-rust-seed1011: a fruit bat at turn 1979

Elf Mage, character level 1, depth 1 (max 1), seed 1011, implementation `rust`, flags `menu`.

Build `a84f5b118fc44f20e0cc8387dd9f13908cbdc5e3` (dirty: no), binary `fb0d9d322fad`. Keys `da1c7108b7a2`; raw logs stay in `/tmp/tmpqw22o7yb/on` (not committed).

Core decision trace: the last 161 of 161 thinks in `trace-core-tail.jsonl`, with selected check, queued keys and `params-core.json`.

**Unassessed.** Basic dossier written by `tools/export-death.py` at the end of the run (RULES 12). Upgrade it with the full death tooling (T1.6) before investigating.
